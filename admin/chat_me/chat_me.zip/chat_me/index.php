<?		
	include('conn.php');
	
	if(isset($_POST['login'])){
	$q="select * from user where username='".$_POST['username']."'";
	$h=mysql_query($q);
	$r=mysql_fetch_array($h);
		
		if($r['password'] == md5($_POST['password'])){
			
			$q2="update user set status='on' where username='$_POST[username]' and password='$r[password]'";
			$h2=mysql_query($q2);
			session_start();
			session_register('username');
			$_SESSION['username'] = $r['username'];
			header('location:chat.php');
		}else{
			echo "failed";
		}
	
	}
?>
<form method=post action="index.php">
username :<input type=text name=username><br>
password :<input type=password name=password><br>
<input type=submit name='login' value=login>
</form>